
public class Personal extends Account {

	public Personal() {
		super("Personal",8000);
	}

}
